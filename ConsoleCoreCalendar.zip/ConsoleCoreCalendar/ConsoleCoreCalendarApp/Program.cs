﻿using System;
using ConsoleCoreCalendarApp;
using ConsoleApiApp;

namespace ConsoleCoreCalendarApp
{
    class Program
    {
        static void Main(string[] args)
        {
            MyCalendar calendar = new MyCalendar();
            calendar.ShowCalendar();
        }
    }
}
