﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace ConsoleApiApp
{
    class MyCalendar
    {
        static int year = new int();
        static int month = new int();
        private static DateTime date;

        public void ShowCalendar()
        {
            Console.Write("Enter the year? ");
            year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the month (January = 1, etc): ");
            month = Convert.ToInt32(Console.ReadLine());

            ShowMyCalendar();
            Console.ReadLine();
        }

        public void ShowMyCalendar() 
        {
            int[,] MyCalendar = new int[6, 7];
            date = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int currentDay = 1;
            int dayOfWeek = (int)date.DayOfWeek;
            date = new DateTime(year, month, currentDay);

            Console.WriteLine("Su Mo Tu We Th Fr Sa");
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    MyCalendar[i, j] = 0;
                   if (i==0 && j < dayOfWeek)
                    {
                        if(i==0 && j == 0)
                        {
                            Console.Write(" " + MyCalendar[i, j]);
                        }
                        else
                        {
                            Console.Write("  " + MyCalendar[i, j]);
                        }

                    }
                    else 
                    {
                        if (currentDay < 10)
                        {
                            if (currentDay == 1)
                            {
                                MyCalendar[i, j] = currentDay;
                                Console.Write("  " + MyCalendar[i, j] + " ");
                            }
                            else
                            {
                                MyCalendar[i, j] = currentDay;
                                Console.Write(" " + MyCalendar[i, j] + " ");
                            }
                        }
                        else
                        {
                            if (currentDay < days+1)
                            {
                                MyCalendar[i, j] = currentDay;
                                Console.Write(MyCalendar[i, j] + " ");
                            }
                            else
                            {
                                Console.Write(MyCalendar[i, j] + "  ");
                            }
                        } 
                        currentDay++;
                    }
                }
              //  if (currentDay < days+1){
                    Console.WriteLine(" ");
               // }
                dayOfWeek = 0;
            }
        }    
    }
}
